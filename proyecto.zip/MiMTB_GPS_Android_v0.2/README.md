# Mi MTB GPS — versión 0.2

Aplicación Android nativa en Kotlin + Jetpack Compose.

## Novedades de v0.2
- Historial local de recorridos completados (SQLite).
- Guarda puntos GPS de cada salida.
- Exportación GPX mediante el selector de documentos de Android.
- Mantiene el mapa online de OpenStreetMap y el registro GPS en primer plano.

## Requisitos
- Android Studio reciente.
- JDK 17.
- Android SDK Platform 35.
- Conexión a Internet para descargar dependencias y teselas del mapa.

## Abrir y compilar
1. Descomprimí el ZIP.
2. En Android Studio: **Open** y elegí la carpeta `MiMTB_GPS_Android_v0.2`.
3. Esperá la sincronización de Gradle.
4. Conectá el Samsung Galaxy S23 Ultra por USB, habilitá Opciones de desarrollador y Depuración USB.
5. Ejecutá con **Run**, o seleccioná **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Si compila, Android Studio mostrará el acceso al APK. Normalmente queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Uso
1. Abrí Mi MTB GPS y concedé ubicación precisa.
2. Tocá **Iniciar recorrido** y permití notificaciones si Android las solicita.
3. Dejá la notificación visible mientras pedaleás; podés apagar la pantalla.
4. Tocá **Finalizar**.
5. Entrá en **Historial** y elegí **Exportar GPX**. Seleccioná dónde guardar el archivo.

## Limitaciones conocidas / pruebas pendientes
- El proyecto fuente fue actualizado, pero no se pudo ejecutar Android Studio ni compilar contra Android SDK en este entorno; por eso no se entrega como APK probado.
- Requiere prueba real en el S23 Ultra: permisos de ubicación, registro con pantalla apagada, consumo de batería, precisión GPS y exportación GPX.
- La app no implementa pausa/reanudación, borrado de actividades ni visualización de la polilínea completa en el mapa.
- Si Android mata el proceso del servicio, esta versión no recupera automáticamente una salida interrumpida.
- El filtro GPS inicial es conservador y debe calibrarse con recorridos reales.
- El servidor público de teselas OpenStreetMap tiene política de uso y disponibilidad best-effort. Para distribución amplia, conviene un proveedor de mapas con condiciones y límites adecuados.
