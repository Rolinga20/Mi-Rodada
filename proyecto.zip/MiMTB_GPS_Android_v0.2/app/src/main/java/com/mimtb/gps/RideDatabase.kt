package com.mimtb.gps

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class RideSummary(
    val id: Long,
    val startedAt: Long,
    val durationSeconds: Long,
    val distanceMeters: Float,
    val averageKmh: Float,
    val maxKmh: Float
)

data class TrackPoint(
    val latitude: Double,
    val longitude: Double,
    val elevation: Double?,
    val timeMillis: Long
)

class RideDatabase(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "mimtbgps.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE rides (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at INTEGER NOT NULL,
                ended_at INTEGER NOT NULL DEFAULT 0,
                duration_seconds INTEGER NOT NULL DEFAULT 0,
                distance_m REAL NOT NULL DEFAULT 0,
                average_kmh REAL NOT NULL DEFAULT 0,
                max_kmh REAL NOT NULL DEFAULT 0
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE track_points (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ride_id INTEGER NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                elevation REAL,
                time_ms INTEGER NOT NULL,
                FOREIGN KEY(ride_id) REFERENCES rides(id)
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_track_ride ON track_points(ride_id, id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun beginRide(startedAt: Long): Long {
        val values = ContentValues().apply { put("started_at", startedAt) }
        return writableDatabase.insertOrThrow("rides", null, values)
    }

    fun addPoint(rideId: Long, point: TrackPoint) {
        val values = ContentValues().apply {
            put("ride_id", rideId)
            put("latitude", point.latitude)
            put("longitude", point.longitude)
            if (point.elevation == null) putNull("elevation") else put("elevation", point.elevation)
            put("time_ms", point.timeMillis)
        }
        writableDatabase.insert("track_points", null, values)
    }

    fun finishRide(id: Long, endedAt: Long, duration: Long, distance: Float, average: Float, max: Float) {
        val values = ContentValues().apply {
            put("ended_at", endedAt)
            put("duration_seconds", duration)
            put("distance_m", distance)
            put("average_kmh", average)
            put("max_kmh", max)
        }
        writableDatabase.update("rides", values, "id=?", arrayOf(id.toString()))
    }

    fun allRides(): List<RideSummary> {
        val result = mutableListOf<RideSummary>()
        readableDatabase.rawQuery(
            "SELECT id, started_at, duration_seconds, distance_m, average_kmh, max_kmh FROM rides WHERE ended_at > 0 ORDER BY started_at DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                result += RideSummary(c.getLong(0), c.getLong(1), c.getLong(2),
                    c.getFloat(3), c.getFloat(4), c.getFloat(5))
            }
        }
        return result
    }

    fun pointsForRide(rideId: Long): List<TrackPoint> {
        val result = mutableListOf<TrackPoint>()
        readableDatabase.rawQuery(
            "SELECT latitude, longitude, elevation, time_ms FROM track_points WHERE ride_id=? ORDER BY id",
            arrayOf(rideId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                result += TrackPoint(
                    c.getDouble(0), c.getDouble(1),
                    if (c.isNull(2)) null else c.getDouble(2),
                    c.getLong(3)
                )
            }
        }
        return result
    }

    fun toGpx(ride: RideSummary): String {
        val points = pointsForRide(ride.id)
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val track = points.joinToString("\n") { point ->
            val ele = point.elevation?.let { "<ele>${"%.1f".format(Locale.US, it)}</ele>" } ?: ""
            """      <trkpt lat="${"%.7f".format(Locale.US, point.latitude)}" lon="${"%.7f".format(Locale.US, point.longitude)}">$ele<time>${iso.format(Date(point.timeMillis))}</time></trkpt>"""
        }
        return """<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="Mi MTB GPS" xmlns="http://www.topografix.com/GPX/1/1">
  <metadata><name>Mi MTB GPS - ${iso.format(Date(ride.startedAt))}</name></metadata>
  <trk><name>Salida en bicicleta</name><trkseg>
$track
  </trkseg></trk>
</gpx>
"""
    }
}
