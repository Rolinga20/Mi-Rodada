package com.mimtb.gps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.android.gms.location.*
import android.content.pm.ServiceInfo
import java.util.concurrent.TimeUnit
import kotlin.math.max

class RideTrackerService : Service() {
    companion object {
        const val ACTION_START = "com.mimtb.gps.START"
        const val ACTION_STOP = "com.mimtb.gps.STOP"
        private const val CHANNEL = "ride_tracking"
        private const val NOTIFICATION_ID = 41
    }

    private lateinit var client: FusedLocationProviderClient
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var database: RideDatabase
    private var previous: Location? = null
    private var startedAt = 0L
    private var rideId = -1L
    private var distanceMeters = 0f
    private var maxSpeed = 0f

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            for (loc in result.locations) accept(loc)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("ride", MODE_PRIVATE)
        database = RideDatabase(this)
        client = LocationServices.getFusedLocationProviderClient(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTracking()
            ACTION_START -> startTracking()
        }
        return START_NOT_STICKY
    }

    private fun startTracking() {
        if (startedAt != 0L) return
        distanceMeters = 0f
        maxSpeed = 0f
        previous = null
        startedAt = System.currentTimeMillis()
        rideId = database.beginRide(startedAt)
        prefs.edit().putBoolean("active", true).putFloat("distance", 0f)
            .putLong("seconds", 0).putFloat("avg", 0f).putFloat("max", 0f).apply()

        val notification = buildNotification("Recorrido en curso")
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(800L)
            .setMinUpdateDistanceMeters(1f)
            .build()
        try {
            client.requestLocationUpdates(request, callback, mainLooper)
        } catch (_: SecurityException) {
            stopTracking()
        }
    }

    private fun accept(location: Location) {
        if (!location.hasAccuracy() || location.accuracy > 25f) return
        val old = previous
        if (old != null) {
            val elapsed = (location.time - old.time).coerceAtLeast(1L)
            val meters = old.distanceTo(location)
            val impliedSpeed = meters / (elapsed / 1000f)
            // Filtro conservador inicial: descarta saltos grandes o velocidades físicamente improbables.
            if (meters > 80f || impliedSpeed > 22f) return
            if (meters >= 2f) {
                distanceMeters += meters
                val speed = if (location.hasSpeed()) location.speed else impliedSpeed
                if (speed in 0f..22f) maxSpeed = max(maxSpeed, speed * 3.6f)
            }
        }
        previous = location
        if (rideId > 0) {
            database.addPoint(rideId, TrackPoint(
                location.latitude, location.longitude,
                if (location.hasAltitude()) location.altitude else null,
                location.time
            ))
        }

        val seconds = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - startedAt)
        val hours = seconds / 3600f
        val average = if (hours > 0f) (distanceMeters / 1000f) / hours else 0f
        prefs.edit()
            .putFloat("distance", distanceMeters)
            .putLong("seconds", seconds)
            .putFloat("avg", average)
            .putFloat("max", maxSpeed)
            .putFloat("lat", location.latitude.toFloat())
            .putFloat("lon", location.longitude.toFloat())
            .apply()
    }

    private fun stopTracking() {
        try { client.removeLocationUpdates(callback) } catch (_: Exception) { }
        if (rideId > 0 && startedAt > 0L) {
            val seconds = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - startedAt)
            val hours = seconds / 3600f
            val average = if (hours > 0f) (distanceMeters / 1000f) / hours else 0f
            database.finishRide(rideId, System.currentTimeMillis(), seconds, distanceMeters, average, maxSpeed)
        }
        prefs.edit().putBoolean("active", false).apply()
        startedAt = 0L
        rideId = -1L
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "Registro de ciclismo", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Mi MTB GPS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()

    override fun onBind(intent: Intent?): IBinder? = null
}
