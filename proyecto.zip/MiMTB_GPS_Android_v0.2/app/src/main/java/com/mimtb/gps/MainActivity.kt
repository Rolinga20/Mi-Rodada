package com.mimtb.gps

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }
    private val gpxLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/gpx+xml")
    ) { uri -> pendingGpx?.let { ride ->
        if (uri != null) writeGpx(uri, ride)
        pendingGpx = null
    } }
    private var pendingGpx: RideSummary? = null

    private fun writeGpx(uri: Uri, ride: RideSummary) {
        val gpx = RideDatabase(this).toGpx(ride)
        contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(gpx) }
    }

    private fun exportRide(ride: RideSummary) {
        pendingGpx = ride
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date(ride.startedAt))
        gpxLauncher.launch("MiMTB_$stamp.gpx")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            userAgentValue = "MiMTB-GPS/0.2"
            // Cache en almacenamiento interno de la app: no requiere permisos de almacenamiento.
            val base = File(filesDir, "osmdroid").apply { mkdirs() }
            val tiles = File(cacheDir, "osmdroid/tiles").apply { mkdirs() }
            osmdroidBasePath = base
            osmdroidTileCache = tiles
        }
        setContent {
            MaterialTheme {
                TrackerScreen(
                    requestPermissions = {
                        permissionLauncher.launch(arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION,
                            Manifest.permission.POST_NOTIFICATIONS
                        ))
                    },
                    exportRide = ::exportRide
                )
            }
        }
    }
}

@Composable
private fun TrackerScreen(requestPermissions: () -> Unit, exportRide: (RideSummary) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ride", Context.MODE_PRIVATE) }
    val database = remember { RideDatabase(context) }
    var active by remember { mutableStateOf(prefs.getBoolean("active", false)) }
    var distance by remember { mutableStateOf(prefs.getFloat("distance", 0f)) }
    var seconds by remember { mutableStateOf(prefs.getLong("seconds", 0L)) }
    var avg by remember { mutableStateOf(prefs.getFloat("avg", 0f)) }
    var max by remember { mutableStateOf(prefs.getFloat("max", 0f)) }
    var lat by remember { mutableStateOf(prefs.getFloat("lat", -26.82f).toDouble()) }
    var lon by remember { mutableStateOf(prefs.getFloat("lon", -65.22f).toDouble()) }
    var showHistory by remember { mutableStateOf(false) }
    var rides by remember { mutableStateOf(database.allRides()) }

    LaunchedEffect(Unit) {
        while (true) {
            active = prefs.getBoolean("active", false)
            distance = prefs.getFloat("distance", 0f)
            seconds = prefs.getLong("seconds", 0L)
            avg = prefs.getFloat("avg", 0f)
            max = prefs.getFloat("max", 0f)
            lat = prefs.getFloat("lat", -26.82f).toDouble()
            lon = prefs.getFloat("lon", -65.22f).toDouble()
            if (showHistory) rides = database.allRides()
            delay(1000)
        }
    }

    fun start() {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine) { requestPermissions(); return }
        context.startForegroundService(Intent(context, RideTrackerService::class.java).setAction(RideTrackerService.ACTION_START))
    }
    fun stop() {
        context.startService(Intent(context, RideTrackerService::class.java).setAction(RideTrackerService.ACTION_STOP))
        rides = database.allRides()
    }
    fun reset() {
        if (!active) {
            prefs.edit().remove("distance").remove("seconds").remove("avg").remove("max").apply()
            distance = 0f; seconds = 0; avg = 0f; max = 0f
        }
    }

    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Mi MTB GPS", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = { showHistory = !showHistory; rides = database.allRides() }) {
                    Text(if (showHistory) "Volver" else "Historial")
                }
            }
            if (showHistory) {
                Text("Tus recorridos guardados", style = MaterialTheme.typography.titleMedium)
                if (rides.isEmpty()) {
                    Text("Todavía no hay salidas guardadas. Finalizá un recorrido para verlo acá.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(rides, key = { it.id }) { ride ->
                            Card {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(ride.startedAt)), fontWeight = FontWeight.Bold)
                                    Text("${"%.2f".format(Locale.getDefault(), ride.distanceMeters / 1000f)} km  ·  ${formatTime(ride.durationSeconds)}")
                                    Text("Media ${"%.1f".format(Locale.getDefault(), ride.averageKmh)} km/h  ·  Máxima ${"%.1f".format(Locale.getDefault(), ride.maxKmh)} km/h")
                                    OutlinedButton(onClick = { exportRide(ride) }, modifier = Modifier.fillMaxWidth()) {
                                        Text("Exportar GPX")
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                AndroidView(
                    modifier = Modifier.fillMaxWidth().height(230.dp),
                    factory = { ctx ->
                        MapView(ctx).apply {
                            setTileSource(TileSourceFactory.MAPNIK)
                            setMultiTouchControls(true)
                            controller.setZoom(13.5)
                            controller.setCenter(GeoPoint(lat, lon))
                        }
                    },
                    update = { map ->
                        map.controller.setCenter(GeoPoint(lat, lon))
                        map.invalidate()
                    }
                )
                Text("© OpenStreetMap contributors", fontSize = 11.sp)
                Spacer(Modifier.height(12.dp))
                Card {
                    Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("DISTANCIA", style = MaterialTheme.typography.labelMedium)
                        Text(String.format(Locale.US, "%.2f km", distance / 1000f), fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Metric("Tiempo", formatTime(seconds))
                            Metric("Vel. media", String.format(Locale.US, "%.1f km/h", avg))
                            Metric("Vel. máxima", String.format(Locale.US, "%.1f km/h", max))
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { if (active) stop() else start() }, modifier = Modifier.weight(1f)) {
                        Text(if (active) "Finalizar" else "Iniciar recorrido")
                    }
                    OutlinedButton(onClick = { reset() }, enabled = !active) { Text("Reiniciar") }
                }
                Text(if (active) "GPS registrando. Podés bloquear la pantalla." else "Listo para comenzar.")
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

private fun formatTime(total: Long): String {
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
